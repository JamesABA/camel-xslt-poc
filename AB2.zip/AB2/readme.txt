Example external configuration for camel-xslt-poc.
---------------------------------------------------

Should be extracted to the root of the drive that the application server can see
The following file must be accessible '/AB2/configuration/override.properties'

route.configuration.folder property must be set to the folder (or file) that contains route information